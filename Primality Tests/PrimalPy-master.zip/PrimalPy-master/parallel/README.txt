This directory contains implementations of the various primality tests
and prime generation algoriths, but with multiprocessing for much higher
efficiency.